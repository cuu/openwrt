For some of these tests newlisp must already be installed (be in the executable path).

Run tests manually one by one.

